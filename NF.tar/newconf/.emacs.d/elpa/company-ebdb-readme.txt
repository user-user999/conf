Company integration for EBDB.  Copied more or less intact from
company-bbdb, originally by Jan Tatarik.
